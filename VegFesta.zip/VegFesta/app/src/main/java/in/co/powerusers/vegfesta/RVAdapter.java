package in.co.powerusers.vegfesta;

import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Powerusers on 19-11-2017.
 */

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.ViewHolder> {
    private List<String> vegs;
    public static class ViewHolder extends RecyclerView.ViewHolder{
        CardView _cv;
        TextView _vegName;
        TextView _vegPrice;
        RelativeLayout _cvLayout;

        public ViewHolder(View v){
            super(v);
            _cv = (CardView)v.findViewById(R.id.cv);
            _vegName = (TextView)v.findViewById(R.id.vegName);
            _vegPrice = (TextView)v.findViewById(R.id.vegPrice);
            _cvLayout = (RelativeLayout)v.findViewById(R.id.cvLayout);

        }
    }

    public RVAdapter(List<String> _vegs){vegs = _vegs;}

    @Override
    public RVAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item,parent,false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(RVAdapter.ViewHolder holder, int position) {
        holder._vegName.setText(vegs.get(position));
    }

    @Override
    public int getItemCount() {
        return vegs.size();
    }
}
